<?php
// ** MySQL settings ** //
define('DB_NAME', 'pl463_lynn');    // The name of the database
define('DB_USER', 'pl463_2_w');     // Your MySQL username
define('DB_PASSWORD', 'ZCE6uz8G'); // ...and password
define('DB_HOST', 'www5.pairlite.com');    // 99% chance you won't need to change this value
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

// You can have multiple installations in one database if you give each a unique prefix
$table_prefix  = strpos($_SERVER['REQUEST_URI'], 'g/amherst/') ? 'wp_amh_' : 'wp_';   // Only numbers, letters, and underscores please!
$which_site = strpos($_SERVER['REQUEST_URI'], 'g/amherst/') ? 'Amherst' : 'Albemarle';

// Change this to localize WordPress.  A corresponding MO file for the
// chosen language must be installed to wp-includes/languages.
// For example, install de.mo to wp-includes/languages and set WPLANG to 'de'
// to enable German language support.
define ('WPLANG', '');

/* That's all, stop editing! Happy blogging. */

define('ABSPATH', dirname(__FILE__).'/');
require_once(ABSPATH.'wp-settings.php');
?>
