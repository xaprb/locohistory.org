<?php
// ** MySQL settings ** //
define('DB_NAME', 'pl463_lynn');    // The name of the database
define('DB_USER', 'pl463_2_w');     // Your MySQL username
define('DB_PASSWORD', 'ZCE6uz8G'); // ...and password
define('DB_HOST', 'www5.pairlite.com');    // 99% chance you won't need to change this value
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Nas`_=#Vr0SDoSMW!$%- +xIuaxz%/o4g!khnvqE*bTu-e3wW054ivnP1Tp[ugtu');
define('SECURE_AUTH_KEY',  'HZEh UaS0(3$cR3~V:rbZ<Jc|_Sh{H^N-&k<.48G 2}UUnih |j%R&  J 6.a<s;');
define('LOGGED_IN_KEY',    'xuwk$_<0x<Z+Pa<+8Dzx$c}geCVi,_=E5G`lp&zACmjJq7[d;PsLS-UGHsQj42qc');
define('NONCE_KEY',        ']o#B7R+i{oR+Fk)%yWNOpron+j*E2aFjH:&Q|OX<s/*n94_e6l~xbawSH^I*sH<Q');
define('AUTH_SALT',        'X~e]t$ aVl(q:D|GRK?_IpP)@owNGIbMHQ2~+H+ezEFPIK,%]8x(|IE>& I=;2(,');
define('SECURE_AUTH_SALT', '#(I,|wGKCaNgP#PV8J#f+sK_h$zK(::DM %ncr3GUm>X;?&zhU@b9~JUz8M<3[bS');
define('LOGGED_IN_SALT',   ';HIO`b-bi ,.<T$Gas,+.3->Z#~yzU7Q}<XF~g~h2Jf{h^(gfiJUj[#gr?W}-S]B');
define('NONCE_SALT',       'DS)K*1XRa92Sg ;f{Lsi+Of/|Gx]B3=VRB&|%ZOD~mG~JfK$^N&OgnkT<_qBwfrc');

/**#@-*/

// You can have multiple installations in one database if you give each a unique prefix
$table_prefix  = strpos($_SERVER['REQUEST_URI'], 'g/amherst/') ? 'wp_amh_' : 'wp_';   // Only numbers, letters, and underscores please!
$which_site = strpos($_SERVER['REQUEST_URI'], 'g/amherst/') ? 'Amherst' : 'Albemarle';

// Change this to localize WordPress.  A corresponding MO file for the
// chosen language must be installed to wp-includes/languages.
// For example, install de.mo to wp-includes/languages and set WPLANG to 'de'
// to enable German language support.
define ('WPLANG', '');

/* That's all, stop editing! Happy blogging. */

define('ABSPATH', dirname(__FILE__).'/');
require_once(ABSPATH.'wp-settings.php');
?>
