/*
File: disableRightClick.js
Authors: Jean-Luc Hardy
Creation date: 17 May 2006
Language: JAVASCRIPT
Copyright: GNU GPL.
Liability: None, i.e. this program is provided as such, without any guarantee whatsoever.

Purpose: 
-------
This script disables the right click on an entire web page or on selected images of a web page.

Installation:
------------
The present file must be inserted in the HTML file before the <body> tag using the following instruction:
<script language="JavaScript" src="path/disableRightClick.js"></script>
where "path/" must be replaced by the appropriate path.

Interface:
---------
Two JavaScript functions can be called: 
disableRightClickImg("msg",this) inserted in <img onload="disableRightClickBody("msg",this)" ...>
or
disableRightClickBody("msg","filter") inserted in <body onload="disableRightClickBody("msg","filter")">
 

For both, "msg" must be replaced by the appropriate message to be displayed in case of a right click. 

disableRightClickImg("msg",this) is used to disable the right click on a particular image.

disableRightClickBody("msg","filter") is used to disable the right click on the entire page.
When "filter" is not present, the right click will be disabled on the entire web page.
When a "filter" is present, the right click will be disabled for all the images whose file name contains "filter".
For example, ".jpg" could be used to protect all the JPG images, but not the GIF images (and not the ".JPG" images). 
For example, ".john" could be used to protect all the JPG images whose file name contains "john".
*/

var msgProtectBodyGlobal;
var selectionBodyGlobal;
var msgProtectGlobal = new Array();

function disableRightClickIE(e){
	if (event.button==2 || event.button==3)
		if (msgProtectGlobal [event.srcElement.src]){
			alert(msgProtectGlobal [event.srcElement.src]);
			return false;}
		else if ((selectionBodyGlobal == "") 
		|| (event.srcElement.src.indexOf(selectionBodyGlobal) != -1)){
			alert(msgProtectBodyGlobal);
			return false;}}

function disableRightClickFF(e) {
	if (e.which==2||e.which==3) {
		if (msgProtectGlobal [this.src])
			alert(msgProtectGlobal [this.src]);
		else 
			alert (msgProtectBodyGlobal);
		return false;}}

function disableRightClickBody(msgProtectParameter,selectionParameter){
	msgProtectBodyGlobal=msgProtectParameter;
	if (selectionParameter) 
		selectionBodyGlobal=selectionParameter;
	else
		selectionBodyGlobal="";

	if (document.all) // MS-IE here
		document.onmousedown=disableRightClickIE;

	//else if (document.layers||(document.getElementById) 
	else { // Firefox here
		document.captureEvents(Event.MOUSEDOWN);
		if (selectionBodyGlobal == ""){
			document.onmousedown=disableRightClickFF;   
			document.oncontextmenu=new Function("return false");}    
		else for (i=0;i<document.images.length;i++)
			if (document.images[i].src.indexOf(selectionBodyGlobal) != -1){
				document.images[i].onmousedown=disableRightClickFF;
				document.images[i].oncontextmenu=new Function("return false");}}}

function disableRightClickImg(msgProtectParameter,theImage){
	msgProtectGlobal[theImage.src]=msgProtectParameter;
	if (document.all) // MS-IE here
		document.onmousedown=disableRightClickIE;
	//else if (document.layers||(document.getElementById) 
	else { // Firefox here
		document.captureEvents(Event.MOUSEDOWN);
		theImage.onmousedown=disableRightClickFF;
		theImage.oncontextmenu=new Function("return false");}}

function disableForSBC() {
   disableRightClickBody('The lending institution requires right-click to be disabled.', '.jpg');
}
