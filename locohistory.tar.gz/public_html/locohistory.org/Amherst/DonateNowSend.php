<?php
$message = <<<EOD
From:  $_POST[firstname] $_POST[lastname]
Email: $_POST[email]
Phone: $_POST[phone]
Message:

$_POST[message]

EOD;

mail('lrainville@sbc.edu', "Donatation to LocoHistory", $message);
header("Location: donatethanks.shtml");
?>
