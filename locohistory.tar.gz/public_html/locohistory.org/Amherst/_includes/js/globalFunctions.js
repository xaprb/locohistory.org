// Functions Created by Dominion Digital (c) 2006
// info@dominiondigital.com

function init() {
	traverseTree(document.getElementById("menu"));
}

function traverseTree(whatTree){
	if (whatTree.hasChildNodes()) {
		for(var i=0;i<whatTree.childNodes.length;i++) {
			var node_str = whatTree.childNodes[i]
			if (node_str.nodeName=="UL") {
				for(var j=0;j<node_str.childNodes.length;j++) {
					var subnode_str = node_str.childNodes[j]
					if (subnode_str.nodeName=="LI") {
						setItAndForgetIt(subnode_str);
						traverseTree(subnode_str);
					}
				}
			}
		}		
	} 
}

function traverseList(whatList){
	if (whatList.hasChildNodes()) {
		for(var i=0;i<whatList.childNodes.length;i++) {
			var node_str = whatList.childNodes[i]
			if (node_str.nodeName=="UL") {
				for(var j=0;j<node_str.childNodes.length;j++) {
					var subnode_str = node_str.childNodes[j]
					if (subnode_str.nodeName=="LI") {
						setItAndForgetIt(subnode_str);
						traverseList(subnode_str);
					}
				}
			}
		}		
	} 
}

function setItAndForgetIt(whichNode) {
	whichNode.onmouseover=function() {
	  this.className+=" over";
	}
	whichNode.onmouseout=function() {
	  this.className="" //this.className.replace(" over", "");
	}
}

function toggleDiv(whichID) {
	var divObject = document.getElementById(whichID)
	if (divObject.style.display == "block") {
		  divObject.style.display = "none";
	} else {
		  divObject.style.display = "block";
	}
}	

function hideDiv(whichID) {
  document.getElementById(whichID).style.display = "none";
}	
function showDiv(whichID) {
  document.getElementById(whichID).style.display = "block";
}	
